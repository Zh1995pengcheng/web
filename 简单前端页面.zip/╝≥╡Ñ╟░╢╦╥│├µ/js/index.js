$(function(){
	$('.ui-search-selected').click(function(){
		$('.ui-search-select-list').slideDown(200);
	});
	$('.ui-search-select-list a').click(function(){
		var index =$(this).index();
		var a = $('.ui-search-select-list a').eq(index).text();
		$('.ui-search-selected').text(a);
		$('.ui-search-select-list').slideUp(200);
	});
	
	$('.item_focus').click(function(){
		$('.block').css('display','block');
		$('.block1').css('display','none');
		$('.item_focus').css({'background-color':'#606ff2','color':'#fff'});
		$('.item_fius').css({'background-color':'transparent','color':'#00B3EA'});
	});
	$('.item_fius').click(function(){
		$('.block1').css('display','block');
		$('.block').css('display','none');
		$('.item_fius').css({'background-color':'#606ff2','color':'#fff'});
		$('.item_focus').css({'background-color':'transparent','color':'#00B3EA'});
	})
	
	
	var time,indes=0,ina=0;
	clearInterval(time);
	han();
	$('.banner-slider').hover(function(){
		clearInterval(time);
	},function(){
		han();
	})
	
	$('.left').click(function(){
		indes +=544;
		ina -=1;
		if(indes ==544){
			indes = -1088;
		}
		if(ina == -1){
			ina = 2;
		}
		$('.ui-slider-wrap').animate({'left':indes+'px'});
		$('.item_focus').css('background-color','#868686');
		$('.item_focus').eq(ina).css('background-color','#1fa4f0');
	})
	$('.right').click(function(){
		indes -=544;
		ina +=1;
		if(indes <= -1632){
					indes =0;
				}
				if(ina >=3){
					ina = 0;
				}
		$('.ui-slider-wrap').animate({'left':indes+'px'});
		$('.item_focus').css('background-color','#868686');
		$('.item_focus').eq(ina).css('background-color','#1fa4f0');
		
	})
	
	$('.item_focus').click(function(){
		var index = $(this).index();
		$('.item_focus').css('background-color','#868686');
		$('.item_focus').eq(index).css('background-color','#1fa4f0');
		ina = index;
		indes = ina*-544;
		$('.ui-slider-wrap').animate({'left':indes+'px'});
	})
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function han(){
	time = setInterval(function(){
				indes -=544;
				ina +=1;
				if(indes <= -1632){
					indes =0;
				}
				if(ina >=3){
					ina = 0;
				}
			$('.ui-slider-wrap').animate({'left':indes+'px'});
			$('.item_focus').css('background-color','#868686');
			$('.item_focus').eq(ina).css('background-color','#1fa4f0');
	},3000);
	}
	
	
	
	
	
	
})